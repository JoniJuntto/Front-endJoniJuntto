import React from 'react';

function SearchList(props) {
    return (
        props.haut.map((haku) =>
        <li>{haku}</li>)
    );
}

export default SearchList;